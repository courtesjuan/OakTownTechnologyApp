// src/helpers/pdfGenerator.js
import { jsPDF } from 'jspdf';
import dayjs from 'dayjs';
import ottInvLogo from '../assets/ottinvlogo.jpg';

/**
 * @param {object} invoice - invoice object from `invoices` table
 * @param {object} client - client object from `clients` table
 * @param {array} lineItems - array of items from `invoice_line_items`
 */
const generateInvoicePDF = ({ invoice, client, lineItems }) => {
  const doc = new jsPDF({ unit: 'pt', format: 'letter' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  const left = 40;
  const right = pageWidth - 40;

  // Colors
  const darkGray = [43, 43, 43];
  const silver = [200, 200, 200];
  const black = [0, 0, 0];

  // Header
  doc.setFontSize(20).setTextColor(...black);
  doc.text(`Invoice #${invoice.invoice_number}`, left, 60);
  doc.setFontSize(12).text(`Date: ${dayjs(invoice.invoice_date).format('MM/DD/YYYY')}`, left, 80);

  try {
    doc.addImage(ottInvLogo, 'JPEG', right - 140, 40, 100, 60);
  } catch (e) {
    doc.setFontSize(10).text('LOGO', right - 100, 70);
  }

  // Client + Description Boxes
  doc.setDrawColor(...darkGray).setLineWidth(0.5);
  doc.rect(left, 120, 260, 120); // Bill To
  doc.rect(left + 280, 120, 260, 120); // Description

  doc.setFontSize(12).text('Bill To:', left + 4, 140);
  const yStart = 160;
  const lineGap = 16;
  const name = `${client.first_name} ${client.last_name}`;
  const cityZip = `${client.city}, ${client.state} ${client.zip}`;
  const billingInfo = [name, client.company, client.address_line1, client.address_line2, cityZip, client.email].filter(Boolean);
  billingInfo.forEach((line, i) => {
    doc.setFontSize(10).text(line, left + 4, yStart + i * lineGap);
  });

  doc.setFontSize(12).text('Description of Work:', left + 284, 140);
  doc.setFontSize(10).text('Services rendered as agreed with client.', left + 284, 160, { maxWidth: 250 });

  // Table Header
  const tableTop = 270;
  doc.setFillColor(...silver);
  doc.rect(left, tableTop - 18, 500, 20, 'F');
  doc.setFontSize(11).setTextColor(...black);
  doc.text('Activity', left + 5, tableTop - 5);
  doc.text('Rate', left + 280, tableTop - 5);
  doc.text('Qty', left + 370, tableTop - 5);
  doc.text('Amount', left + 450, tableTop - 5);

  // Table Rows
  let currentY = tableTop + 10;
  let total = 0;
  lineItems.forEach((item) => {
    const amt = item.amount || (item.quantity * item.rate);
    total += amt;
    doc.setFontSize(10);
    doc.text(item.activity || '', left + 5, currentY);
    doc.text(`$${parseFloat(item.rate).toFixed(2)}`, left + 280, currentY);
    doc.text(`${parseFloat(item.quantity).toFixed(2)}`, left + 370, currentY);
    doc.text(`$${amt.toFixed(2)}`, left + 450, currentY);
    currentY += 20;
  });

  // Total Due
  currentY += 20;
  doc.setFontSize(12).text('Total Due:', left + 370, currentY);
  doc.setFontSize(14).text(`$${total.toFixed(2)}`, left + 450, currentY);

  // Footer
  doc.setFontSize(10).setTextColor(...darkGray);
  doc.text('Thank you for your business!', left, pageHeight - 40);

  doc.save(`Invoice_${invoice.invoice_number}.pdf`);
};

export default generateInvoicePDF;
